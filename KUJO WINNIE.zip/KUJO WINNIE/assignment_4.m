clc;
clear;
close all;

% LEAF STRUCTURE ARRAY
leaves(1).shape = 'Ovate';
leaves(1).margin = 'Serrated';
leaves(1).venation = 'Pinnate';
leaves(1).apex = 'Acute';
leaves(1).base = 'Cuneate';
leaves(1).arrangement = 'Alternate';
leaves(1).type = 'Simple';
leaves(1).texture = 'Smooth';

leaves(2).shape = 'Elliptic';
leaves(2).margin = 'Entire';
leaves(2).venation = 'Pinnate';
leaves(2).apex = 'Acute';
leaves(2).base = 'Cuneate';
leaves(2).arrangement = 'Opposite';
leaves(2).type = 'Simple';
leaves(2).texture = 'Smooth';

leaves(3).shape = 'Lanceolate';
leaves(3).margin = 'Entire';
leaves(3).venation = 'Pinnate';
leaves(3).apex = 'Acuminate';
leaves(3).base = 'Cuneate';
leaves(3).arrangement = 'Alternate';
leaves(3).type = 'Simple';
leaves(3).texture = 'Smooth';

leaves(4).shape = 'Linear';
leaves(4).margin = 'Entire';
leaves(4).venation = 'Parallel';
leaves(4).apex = 'Acute';
leaves(4).base = 'Cuneate';
leaves(4).arrangement = 'Alternate';
leaves(4).type = 'Simple';
leaves(4).texture = 'Smooth';

leaves(5).shape = 'Cordate';
leaves(5).margin = 'Serrated';
leaves(5).venation = 'Palmate';
leaves(5).apex = 'Acuminate';
leaves(5).base = 'Cordate';
leaves(5).arrangement = 'Alternate';
leaves(5).type = 'Simple';
leaves(5).texture = 'Smooth';

leaves(6).shape = 'Palmate-lobed';
leaves(6).margin = 'Lobed';
leaves(6).venation = 'Palmate';
leaves(6).apex = 'Acute';
leaves(6).base = 'Cordate';
leaves(6).arrangement = 'Alternate';
leaves(6).type = 'Simple';
leaves(6).texture = 'Smooth';

% image processing
for i = 1:6
    filename = ['leaf' num2str(i) '.jpg'];
    leaves(i).originalImage = imread(filename);
    leaves(i).grayImage = rgb2gray(leaves(i).originalImage);
    leaves(i).binaryImage = imbinarize(leaves(i).grayImage);
    leaves(i).edgeImage = edge(leaves(i).grayImage);
end

% display structural array information
for i = 1:6
    fprintf('LEAF %d\n\n', i);
    fprintf('Shape: %s\n', leaves(i).shape);
    fprintf('Margin: %s\n', leaves(i).margin);
    fprintf('Venation: %s\n', leaves(i).venation);
    fprintf('Apex: %s\n', leaves(i).apex);
    fprintf('Base: %s\n', leaves(i).base);
    fprintf('Arrangement: %s\n', leaves(i).arrangement);
    fprintf('Type: %s\n', leaves(i).type);
    fprintf('Texture: %s\n', leaves(i).texture);
end

% displaying images
for i = 1:6
    figure;
    subplot(2,2,1);
    imshow(leaves(i).originalImage);
    title(['Original Leaf ' num2str(i)]);
    subplot(2,2,2);
    imshow(leaves(i).grayImage);
    title('Grayscale');
    subplot(2,2,3);
    imshow(leaves(i).binaryImage);
    title('Binary');
    subplot(2,2,4);
    imshow(leaves(i).edgeImage);
    title('Edge');
end